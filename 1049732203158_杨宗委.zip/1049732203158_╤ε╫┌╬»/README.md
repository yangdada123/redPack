requirement：redis-4.0 redisbloom-1.1.1

环境：CentOS 7.x

一：安装布隆过滤器
1、软件下载：略
2、解压：tar -zxvf v1.1.1.tar.gz
3、进入解压目录：cd RedisBloom-1.1.1
4、编译：make   
PS：编译成功后，会有个rebloom.so文件

二：安装Redis：
1、软件下载：略
2、软件解压：tar -zxvf redis-4.0.5.tar.gz [-C /usr/local]
3、进入解压目录：cd redis-4.0.5
4、编译并安装：make PREFIX=/usr/local/redis4 install
5、复制配置文件：将Redis解压目录下的redis.conf文件复制到安装好的redis4/bin/目录下  cp soruce dest
6、修改配置文件：vim redis.conf  在最后一行添加如下配置：加载布隆过滤器插件
loadmodule /root/RedisBloom-1.1.1/rebloom.so

redis：redis.conf   通过终端工具连接
bind 0.0.0.0
