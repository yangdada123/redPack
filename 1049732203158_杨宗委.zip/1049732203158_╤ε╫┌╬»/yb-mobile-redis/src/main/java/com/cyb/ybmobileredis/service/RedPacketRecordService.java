package com.cyb.ybmobileredis.service;

import com.cyb.ybmobileredis.domain.RedPacketRecord;

public interface RedPacketRecordService {
    void insert(RedPacketRecord redPacketRecord);
}
