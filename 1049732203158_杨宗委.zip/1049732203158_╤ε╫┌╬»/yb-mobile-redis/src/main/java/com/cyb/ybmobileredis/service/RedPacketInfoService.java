package com.cyb.ybmobileredis.service;

import com.cyb.ybmobileredis.domain.RedPacketInfo;

public interface RedPacketInfoService {
    void insert(RedPacketInfo redPacketInfo);
}
