package com.cyb.ybmobileredis.mapper;

import com.cyb.ybmobileredis.domain.RedPacketRecord;

public interface RedPacketRecordMapper {
    void insert(RedPacketRecord redPacketRecord);
}
